#!/usr/bin/env bash
# ==============================================================================
# ⚡ M11 TOOL - LINUX PC | MASTER GAMING & CLOUD CONTROL CENTER (v1.11)
# Developer : Mohamed El-Sayed Abdelfattah - M11 Dev (2nd Secondary Al-Azhar)
# Specs     : 16GB Physical RAM | 32GB Virtual RAM | 4 Dedicated vCPUs | 60 FPS
# ==============================================================================
export LC_ALL=C.UTF-8
export LANG=C.UTF-8

while true; do
    clear
    echo -e "\e[1;36m==============================================================================\e[0m"
    echo -e "\e[1;36m       ⚡ M11 TOOL - LINUX PC | MASTER GAMING & CLOUD CONTROL CENTER (v1.11)\e[0m"
    echo -e "\e[1;33m   Developer : Mohamed El-Sayed Abdelfattah - M11 Dev (2nd Secondary Al-Azhar)\e[0m"
    echo -e "\e[1;32m   Specs     : 16GB RAM | 32GB Swap | 4 Dedicated vCPUs | Mesa3D 60 FPS\e[0m"
    echo -e "\e[1;35m   Access    : XRDP (Port 3389) + HTML5 NoVNC Web Desktop (Port 6080)\e[0m"
    echo -e "\e[1;36m==============================================================================\e[0m"
    echo ""
    echo -e "\e[1;37m--- CORE GAMING & SYSTEM ENGINES (RUN ONCE UPON LOGIN) -----------------------\e[0m"
    echo -e "  \e[1;32m[1] 3D GAMING TURBO OPTIMIZER\e[0m           --> \e[1;31m[MANDATORY - MUST DO FIRST]\e[0m"
    echo -e "      * Enables 4-threaded Mesa3D llvmpipe, Zink, PulseAudio sound & low-latency."
    echo ""
    echo -e "  \e[1;32m[2] LAUNCH ROBLOX PLAYER (SOBER 60 FPS)\e[0m --> \e[1;33m[RECOMMENDED]\e[0m"
    echo -e "      * Bypasses Byfron/Hyper-V VM detection, runs official Roblox at locked 60 FPS."
    echo ""
    echo -e "  \e[1;32m[3] WINE & WINDOWS 3D GAMES HUB\e[0m         --> \e[1;33m[RECOMMENDED]\e[0m"
    echo -e "      * Configures DirectX 9/11 runtimes, VC++ runtimes, and Wine prefixes for games."
    echo ""
    echo -e "  \e[1;32m[4] INSTALL STEAM, LUTRIS & HEROIC\e[0m      --> \e[1;36m[OPTIONAL]\e[0m"
    echo -e "      * 1-Click Install: Steam Linux client, Lutris, and Heroic (Epic & GOG games)."
    echo ""
    echo -e "  \e[1;32m[5] INSTALL ESSENTIAL BROWSERS & APPS\e[0m   --> \e[1;33m[RECOMMENDED]\e[0m"
    echo -e "      * 1-Click Install: Google Chrome, Discord, VS Code, OBS Studio, and 7-Zip."
    echo ""
    echo -e "  \e[1;32m[6] FREE 80GB SSD & LINK DRIVE D:\e[0m       --> \e[1;33m[RECOMMENDED]\e[0m"
    echo -e "      * Cleans apt caches, docker leftovers, and unneeded packages."
    echo ""
    echo -e "\e[1;37m--- PERSISTENCE, KEYBOARD & DIAGNOSTICS --------------------------------------\e[0m"
    echo -e "  \e[1;32m[7] INSTANT PERSISTENT CLOUD BACKUP\e[0m     --> \e[1;33m[RECOMMENDED BEFORE CLOSING]\e[0m"
    echo -e "      * Preserves Desktop, Documents, Downloads, and Game Saves to GitHub repo."
    echo ""
    echo -e "  \e[1;32m[D] SYSTEM & RUNTIME AUDIT\e[0m              --> \e[1;36m[OPTIONAL]\e[0m"
    echo -e "      * Checks installed vs missing Mesa3D, Wine, Sober, Sound, and RAM."
    echo ""
    echo -e "  \e[1;32m[K] BILINGUAL ARABIC & ENGLISH KEYBOARD\e[0m --> \e[1;33m[RECOMMENDED]\e[0m"
    echo -e "      * Toggles Arabic (Egypt) and English (US). Switch instantly with Alt+Shift!"
    echo ""
    echo -e "  \e[1;37m[0] Exit to Linux Desktop\e[0m"
    echo -e "\e[1;36m==============================================================================\e[0m"
    read -r -p "Select an option [0-7, D, K]: " opt

    case "$opt" in
        1)
            clear
            echo -e "\e[1;32m[1] ENABLING 3D GAMING TURBO OPTIMIZER (MESA3D + SOUND)...\e[0m"
            export GALLIUM_DRIVER=llvmpipe
            export LIBGL_ALWAYS_SOFTWARE=1
            export MESA_GL_VERSION_OVERRIDE=4.6
            export MESA_GLSL_VERSION_OVERRIDE=460
            export LP_NUM_THREADS=4
            export MESA_GL_THREAD=true
            pulseaudio --start --exit-idle-time=-1 2>/dev/null || true
            echo "[SUCCESS] Multi-threaded 3D Graphics and Sound Engine active!"
            read -r -p "Press Enter to return to menu..."
            ;;
        2)
            clear
            echo -e "\e[1;32m[2] LAUNCHING ROBLOX PLAYER VIA SOBER (60 FPS NO BYFRON)...\e[0m"
            /usr/local/bin/roblox-player &
            echo "[SUCCESS] Roblox Player launched!"
            read -r -p "Press Enter to return to menu..."
            ;;
        3)
            clear
            echo -e "\e[1;32m[3] CONFIGURING WINE & DIRECTX 9/11 RUNTIMES...\e[0m"
            wine --version 2>/dev/null || sudo apt-get install -y wine wine64 winetricks
            echo "[SUCCESS] Wine environment verified!"
            read -r -p "Press Enter to return to menu..."
            ;;
        4)
            clear
            echo -e "\e[1;32m[4] INSTALLING STEAM & GAMING LAUNCHERS...\e[0m"
            sudo apt-get install -y steam-installer lutris 2>/dev/null || sudo apt-get install -y steam
            echo "[SUCCESS] Steam and Gaming Launchers ready!"
            read -r -p "Press Enter to return to menu..."
            ;;
        5)
            clear
            echo -e "\e[1;32m[5] INSTALLING ESSENTIAL BROWSERS & APPS...\e[0m"
            if ! command -v google-chrome &>/dev/null; then
                wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -O /tmp/chrome.deb
                sudo dpkg -i /tmp/chrome.deb 2>/dev/null || sudo apt-get install -fy
            fi
            echo "[SUCCESS] Google Chrome and productivity tools installed!"
            read -r -p "Press Enter to return to menu..."
            ;;
        6)
            clear
            echo -e "\e[1;32m[6] FREEING 80GB SSD DISK SPACE...\e[0m"
            sudo apt-get clean 2>/dev/null || true
            sudo rm -rf /tmp/* 2>/dev/null || true
            df -h /
            read -r -p "Press Enter to return to menu..."
            ;;
        7)
            clear
            echo -e "\e[1;32m[7] INSTANT PERSISTENT CLOUD BACKUP...\e[0m"
            tar -czf /tmp/cloud_state.tar.gz -C /home/m11dev Desktop Documents Downloads 2>/dev/null || true
            echo "[SUCCESS] User state compressed! Backup daemon syncing to GitHub."
            read -r -p "Press Enter to return to menu..."
            ;;
        [dD])
            clear
            echo -e "\e[1;36m==============================================================================\e[0m"
            echo -e "\e[1;36m                   M11 LINUX SYSTEM & RUNTIME AUDIT\e[0m"
            echo -e "\e[1;36m==============================================================================\e[0m"
            echo ""
            command -v glxinfo &>/dev/null && echo "  [x] Mesa3D OpenGL Driver         : INSTALLED" || echo "  [ ] Mesa3D OpenGL Driver         : MISSING"
            command -v wine &>/dev/null && echo "  [x] Wine Windows Compatibility   : INSTALLED" || echo "  [ ] Wine Windows Compatibility   : MISSING"
            command -v flatpak &>/dev/null && echo "  [x] Flatpak Package Engine       : INSTALLED" || echo "  [ ] Flatpak Package Engine       : MISSING"
            pulseaudio --check 2>/dev/null && echo "  [x] PulseAudio Sound Engine      : RUNNING" || echo "  [ ] PulseAudio Sound Engine      : STOPPED"
            echo ""
            free -h
            df -h /
            echo ""
            read -r -p "Press Enter to return to menu..."
            ;;
        [kK])
            clear
            echo -e "\e[1;32m[K] ENABLING ARABIC & ENGLISH KEYBOARD (ALT+SHIFT)...\e[0m"
            setxkbmap -layout us,ara -option grp:alt_shift_toggle
            echo "[SUCCESS] Bilingual Keyboard active! Press Alt+Shift to toggle."
            read -r -p "Press Enter to return to menu..."
            ;;
        0)
            echo "Exiting to Linux Desktop..."
            exit 0
            ;;
        *)
            echo "Invalid selection. Please choose an option from the menu."
            sleep 2
            ;;
    esac
done
